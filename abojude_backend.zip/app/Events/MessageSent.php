<?php

namespace App\Events;

use App\Models\Message;
use App\Helpers\helpers;
use Exception;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class MessageSent implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $message;

    /**
     * Create a new event instance.
     */
    public function __construct(Message $message)
    {
        $this->message = $message;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return array<int, \Illuminate\Broadcasting\Channel>
     */
    public function broadcastOn(): array
    {
        return [
            new Channel('chat.' . $this->message->conversation_id),
        ];
    }

    /**
     * The event's broadcast name.
     */
    public function broadcastAs(): string
    {
        return 'message.sent';
    }

    /**
     * Get the data to broadcast.
     *
     * @return array<string, mixed>
     */
    public function broadcastWith(): array
    {
        $post = $this->message->conversation?->post;

        return [
            'id' => $this->message->id,
            'conversation_id' => $this->message->conversation_id,
            'post_id' => $this->message->conversation?->post_id,
            'post_title' => $post?->title,
            'post_thumbnail' => $this->getImageUrl($post?->thumbnail),
            'sender_id' => $this->message->sender_id,
            'sender_name' => $this->message->sender?->name ?? 'User',
            'message' => $this->message->message,
            'attachment' => $this->getImageUrl($this->message->attachment),
            'is_read' => (bool)$this->message->is_read,
            'created_at' => $this->message->created_at,
            'time_ago' => $this->message->created_at ? Carbon::parse($this->message->created_at)->format('M d, g:i A') : null,
        ];
    }

    /**
     * Helper to get image URL.
     */
    private function getImageUrl($path)
    {
        if (!$path) {
            return null;
        }
        try {
            return helpers::generateTempURL($path, config('app.file_system'));
        } catch (Exception $e) {
            return Storage::disk(config('app.file_system'))->url($path);
        }
    }
}
